# Finite gate expansions with bounded messages

The two modules construct an actual finite list of party monomials from the original weighted list of message monomials. The constructed list preserves the operator and the pair-effect bound. Its exact term count is the sum of the original products of message dimensions, and its coefficient sum is the same sum weighted by the original coefficient norms. Consequently, at most K original terms with at most m messages of dimension at most D give at most K D^m terms and increase the coefficient sum by at most D^m.

The second module places this constructed list in the existing original-circuit constructor, using the original owner embedding and spectator layout. The required contraction follows from the norm bound on the original message-containing operator. The original gate remains one occurrence with precisely its prescribed participant set. There is no assumed expanded-gate norm or desired decomposition identity.

The source is polynomial-PEPS Theorem 5.2, 04-compression.tex, lines 32–43 and 143–149. This is the bounded-message reduction, not a claim that the entire theorem has been assembled. Empty lists, zero-dimensional transferred spaces, repeated monomials and empty scalar participant sets remain covered. The nonprivate constructor excludes exactly singleton participant sets, as its existing definition requires.

## Verification

Both exact source files passed raw Lean with all package options and warningAsError. The imported kernel audit covers all 16 public declarations and reports only propext, Classical.choice and Quot.sound. All 4,964 actually imported artifacts are recorded by SHA-256. No Lake cache or dependency pin was changed. Independent mathematical review by the message-monomial proof author passed.

- TNLean.PEPS.Approximation.MessageGateExpansion: 3.495 s; source SHA-256 5b09fff5a88e0bd252aee4347ddf11c4c461e1483efd62a5c3886f16f943c0f3.
- TNLean.PEPS.Approximation.MessageGateCircuit: 3.317 s; source SHA-256 013311ff75bf15f4d8419b60cb4baeeeb43049d097b7399eba1fd1d16ea3f26f.
- Imported audit: 3.619 s.

## Canonical adoption

These are scratch sources; source_revision is intentionally null. Record the canonical source revision after adoption and provenance insertion, then recheck the exact adopted bytes. A proof-pattern review should inspect the mapped-list membership steps around Mathlib's sum_le_length_nsmul: the same existing estimate is also applied in GateCoefficientBounds. A shared mapped-list form may shorten those uses; no new generic mathematical estimate is required.
