import TNLean.PEPS.Approximation.MessageGateCircuit

set_option linter.hashCommand false
namespace TNLean.PEPS.PairEffect
#print axioms MessageGate
end TNLean.PEPS.PairEffect
namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms eval
end TNLean.PEPS.PairEffect.MessageGate
namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms expand
end TNLean.PEPS.PairEffect.MessageGate
namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms mem_expand
end TNLean.PEPS.PairEffect.MessageGate
namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms eval_expand
end TNLean.PEPS.PairEffect.MessageGate
namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms isAllowed_expand
end TNLean.PEPS.PairEffect.MessageGate
namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms effectCount_expand_le
end TNLean.PEPS.PairEffect.MessageGate
namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms expansion_size
end TNLean.PEPS.PairEffect.MessageGate
namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms expansion_size_le
end TNLean.PEPS.PairEffect.MessageGate
namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms expansion_size_le_of_coeff_le
end TNLean.PEPS.PairEffect.MessageGate
namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms toOriginalCircuit
end TNLean.PEPS.PairEffect.MessageGate
namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms eval_toOriginalCircuit
end TNLean.PEPS.PairEffect.MessageGate
namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms nonprivateCount_toOriginalCircuit
end TNLean.PEPS.PairEffect.MessageGate
namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms participants_toOriginalCircuit
end TNLean.PEPS.PairEffect.MessageGate
namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms isExpansionBounded_toOriginalCircuit
end TNLean.PEPS.PairEffect.MessageGate
namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms isMonomialBounded_toOriginalCircuit
end TNLean.PEPS.PairEffect.MessageGate

run_cmd do
  let environment ← Lean.getEnv
  let names := environment.header.moduleNames.map (fun n ↦ Lean.Json.str n.toString)
  IO.FS.writeFile "../final-verification-20261008/imported-modules.json"
    (Lean.Json.compress (Lean.Json.arr names))
