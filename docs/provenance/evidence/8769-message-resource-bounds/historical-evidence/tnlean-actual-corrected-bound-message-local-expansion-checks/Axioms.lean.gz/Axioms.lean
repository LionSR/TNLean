import TNLean.PEPS.Approximation.LocalTransferExpansion
import TNLean.PEPS.Approximation.TransferGateExpansion
import TNLean.PEPS.Approximation.PartyChainComposition

set_option linter.hashCommand false
namespace TNLean.PEPS.PairEffect.Word
#print axioms localDiscard
end TNLean.PEPS.PairEffect.Word
namespace TNLean.PEPS.PairEffect.Word
#print axioms isAllowed_localDiscard
end TNLean.PEPS.PairEffect.Word
namespace TNLean.PEPS.PairEffect.Word
#print axioms eval_localDiscard_tmul
end TNLean.PEPS.PairEffect.Word
namespace TNLean.PEPS.PairEffect.Word
#print axioms transferTerm
end TNLean.PEPS.PairEffect.Word
namespace TNLean.PEPS.PairEffect.Word
#print axioms isAllowed_transferTerm
end TNLean.PEPS.PairEffect.Word
namespace TNLean.PEPS.PairEffect.Word
#print axioms sources_transferTerm
end TNLean.PEPS.PairEffect.Word
namespace TNLean.PEPS.PairEffect.Word
#print axioms eval_transferTerm_tmul
end TNLean.PEPS.PairEffect.Word
namespace TNLean.PEPS.PairEffect.Word
#print axioms sum_eval_transferTerm
end TNLean.PEPS.PairEffect.Word
namespace TNLean.PEPS.PairEffect
#print axioms gate_toGate_eq_sum
end TNLean.PEPS.PairEffect
namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms transfer
end TNLean.PEPS.PairEffect.PartyGate
namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms length_transfer
end TNLean.PEPS.PairEffect.PartyGate
namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms isAllowed_effectCount_transfer
end TNLean.PEPS.PairEffect.PartyGate
namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms sum_norm_coeff_transfer
end TNLean.PEPS.PairEffect.PartyGate
namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms eval_transfer
end TNLean.PEPS.PairEffect.PartyGate
namespace TNLean.PEPS.PairEffect.PartyChain
#print axioms prependWord
end TNLean.PEPS.PairEffect.PartyChain
namespace TNLean.PEPS.PairEffect.PartyChain
#print axioms eval_prependWord
end TNLean.PEPS.PairEffect.PartyChain
namespace TNLean.PEPS.PairEffect.PartyChain
#print axioms isAllowed_prependWord
end TNLean.PEPS.PairEffect.PartyChain
namespace TNLean.PEPS.PairEffect.PartyChain
#print axioms effectCount_prependWord
end TNLean.PEPS.PairEffect.PartyChain
namespace TNLean.PEPS.PairEffect.PartyChain
#print axioms comp
end TNLean.PEPS.PairEffect.PartyChain
namespace TNLean.PEPS.PairEffect.PartyChain
#print axioms eval_comp
end TNLean.PEPS.PairEffect.PartyChain
namespace TNLean.PEPS.PairEffect.PartyChain
#print axioms isAllowed_comp
end TNLean.PEPS.PairEffect.PartyChain
namespace TNLean.PEPS.PairEffect.PartyChain
#print axioms effectCount_comp
end TNLean.PEPS.PairEffect.PartyChain

run_cmd do
  let environment ← Lean.getEnv
  let names := environment.header.moduleNames.map (fun n ↦ Lean.Json.str n.toString)
  IO.FS.writeFile "imported-modules.json" (Lean.Json.compress (Lean.Json.arr names))
