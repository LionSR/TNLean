import TNLean.PEPS.Approximation.PhysicalFirstPolynomial

set_option linter.hashCommand false
namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms card_sourceLocations_physicalFirstReplacement_le
end TNLean.PEPS.PairEffect.OriginalCircuit
namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms sourceSamplingCount_physicalFirstReplacement_lt_power
end TNLean.PEPS.PairEffect.OriginalCircuit
namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms card_branchLabels_physicalFirstReplacement_le_power
end TNLean.PEPS.PairEffect.OriginalCircuit

run_cmd do
  let environment ← Lean.getEnv
  let names := environment.header.moduleNames.map (fun n ↦ Lean.Json.str n.toString)
  IO.FS.writeFile "imported-modules.json" (Lean.Json.compress (Lean.Json.arr names))
