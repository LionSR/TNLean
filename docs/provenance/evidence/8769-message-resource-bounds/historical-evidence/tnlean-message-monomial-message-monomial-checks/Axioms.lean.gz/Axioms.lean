import TNLean.PEPS.Approximation.MessageMonomial

/-! # Imported audit of finite-message monomial expansion. -/
set_option linter.hashCommand false

#print axioms
  TNLean.PEPS.PairEffect.MessageMonomial
#print axioms
  TNLean.PEPS.PairEffect.MessageMonomial.eval
#print axioms
  TNLean.PEPS.PairEffect.MessageMonomial.IsAllowed
#print axioms
  TNLean.PEPS.PairEffect.MessageMonomial.messageDimensions
#print axioms
  TNLean.PEPS.PairEffect.MessageMonomial.effectCount
#print axioms
  TNLean.PEPS.PairEffect.MessageMonomial.expand
#print axioms
  TNLean.PEPS.PairEffect.MessageMonomial.eval_expand
#print axioms
  TNLean.PEPS.PairEffect.MessageMonomial.isAllowed_effectCount_expand
#print axioms
  TNLean.PEPS.PairEffect.MessageMonomial.expansion_size
#print axioms
  TNLean.PEPS.PairEffect.MessageMonomial.expansion_size_le
#print axioms
  TNLean.PEPS.PairEffect.MessageMonomial.expansion_size_le_of_power_bounds

run_cmd do
  let environment ← Lean.getEnv
  let names := environment.header.moduleNames.map (fun n ↦ Lean.Json.str n.toString)
  let directory : System.FilePath := "/private/tmp/tnlean-message-monomial"
  IO.FS.writeFile (directory / "message-monomial-checks" / "imported-modules.json")
    (Lean.Json.compress (Lean.Json.arr names))
