import TNLean.PEPS.Approximation.PartyGateComposition

set_option linter.hashCommand false
namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms comp
end TNLean.PEPS.PairEffect.PartyGate
namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms mem_comp
end TNLean.PEPS.PairEffect.PartyGate
namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms gate_comp
end TNLean.PEPS.PairEffect.PartyGate
namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms length_comp
end TNLean.PEPS.PairEffect.PartyGate
namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms sum_norm_comp
end TNLean.PEPS.PairEffect.PartyGate
namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms isAllowed_comp
end TNLean.PEPS.PairEffect.PartyGate
namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms effectCount_comp_le
end TNLean.PEPS.PairEffect.PartyGate

run_cmd do
  let environment ← Lean.getEnv
  let names := environment.header.moduleNames.map (fun n ↦ Lean.Json.str n.toString)
  IO.FS.writeFile "../final-verification-20261008/imported-modules.json"
    (Lean.Json.compress (Lean.Json.arr names))
