import TNLean.PEPS.Approximation.PhysicalFirstNetworkResources

set_option linter.hashCommand false
namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms physicalFirstReplacementLocationsEquiv
end TNLean.PEPS.PairEffect.OriginalCircuit
namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms participants_physicalFirstReplacementLocationsEquiv
end TNLean.PEPS.PairEffect.OriginalCircuit
namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms exists_original_gate_of_physicalFirst_link
end TNLean.PEPS.PairEffect.OriginalCircuit
namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms card_incidentPhysicalFirstLinks_le
end TNLean.PEPS.PairEffect.OriginalCircuit

run_cmd do
  let environment ← Lean.getEnv
  let names := environment.header.moduleNames.map (fun n ↦ Lean.Json.str n.toString)
  IO.FS.writeFile "imported-modules.json" (Lean.Json.compress (Lean.Json.arr names))
