# Finite original input memory

The single theorem derives finite-dimensionality of the actual whole-party input memory from finite-dimensionality of each original party space. It imposes no numerical dimension bound, no nontriviality condition and no nonempty-party condition. A finite orthonormal input basis can therefore be chosen by stdOrthonormalBasis after installing this instance. This discharges the coordinate premise from the manuscript convention that every Hilbert space is finite-dimensional (04-compression.tex, lines17–19), applied to its normalized party-product input (lines137–139).

The exact source passed all package options and warningAsError. The imported audit reports only standard kernel axioms and hashes every imported artifact. No cache or repository source was modified.
