import TNLean.PEPS.Approximation.FiniteInputMemory

set_option linter.hashCommand false
namespace TNLean.PEPS.PairEffect.ProductInput
#print axioms finiteDimensional_wholePartyMem
end TNLean.PEPS.PairEffect.ProductInput

run_cmd do
  let environment ← Lean.getEnv
  let names := environment.header.moduleNames.map (fun n ↦ Lean.Json.str n.toString)
  IO.FS.writeFile "../final-verification-20261008/imported-modules.json"
    (Lean.Json.compress (Lean.Json.arr names))
