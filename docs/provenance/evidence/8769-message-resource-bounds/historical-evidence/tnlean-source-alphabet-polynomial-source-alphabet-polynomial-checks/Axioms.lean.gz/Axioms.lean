import TNLean.PEPS.Approximation.SourceAlphabetPolynomial

/-! # Imported audit of actual source-network alphabet bounds. -/
set_option linter.hashCommand false

#print axioms
  TNLean.PEPS.PairEffect.SourceCircuit.card_sourceNetworkAlphabet_le_of_power_bounds

run_cmd do
  let environment ← Lean.getEnv
  let names := environment.header.moduleNames.map (fun n ↦ Lean.Json.str n.toString)
  let directory : System.FilePath := "/private/tmp/tnlean-source-alphabet-polynomial"
  IO.FS.writeFile (directory / "source-alphabet-polynomial-checks" / "imported-modules.json")
    (Lean.Json.compress (Lean.Json.arr names))
