# Polynomial cardinalities of actual source-network alphabets

The sole public theorem applies to the actual branch-label pairs and sample indices on DistributedOperatorContraction links of an existing SourceCircuit. From actual branch counts≤C_M L^u and actual sample count k≤C_k L^v, it derives alphabet cardinality≤(C_M²+C_k)L^max(2u,v). It uses the existing exact per-link cardinality theorem, not a ceiling of a global branch bound. No private-memory, Schmidt-rank, normalized-source, contraction, or full-network identification hypothesis is introduced.

Canonical raw Lean verification passed in 3.193 seconds with all package options and warningAsError, with zero diagnostics. The separate imported audit passed in 3.033 seconds; only propext, Classical.choice and Quot.sound occur. The 4,690 actual imported artifacts are hashed with resolved paths. Root independently reviewed the mathematics and scope. This is direct Lean verification, not a Lake build or blueprint checkdecls run. No repository source or build cache was changed.

SourceAlphabetPolynomial.lean is frozen in the source manifest. Its blueprint draft has exactly one matching tag, recorded in blueprint-coverage.json. The result is a scoped polynomial virtual-dimension estimate, not the complete tensor-network reconstruction theorem. Canonical adoption and provenance notices remain with the integration owner.
