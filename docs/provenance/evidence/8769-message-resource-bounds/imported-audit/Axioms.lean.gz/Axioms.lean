import TNLean

/-! Imported axiom check of the new source identities and refactored declarations. -/
set_option linter.hashCommand false

namespace TNLean.PEPS.PairEffect.Word
#print axioms eval_localDiscard_tmul
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Word
#print axioms eval_transferTerm_tmul
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Word
#print axioms isAllowed_localDiscard
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Word
#print axioms isAllowed_transferTerm
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Word
#print axioms localDiscard
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Word
#print axioms sources_transferTerm
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Word
#print axioms sum_eval_transferTerm
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Word
#print axioms transferTerm
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms eval_transfer
end TNLean.PEPS.PairEffect.PartyGate

namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms isAllowed_effectCount_transfer
end TNLean.PEPS.PairEffect.PartyGate

namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms length_transfer
end TNLean.PEPS.PairEffect.PartyGate

namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms sum_norm_coeff_transfer
end TNLean.PEPS.PairEffect.PartyGate

namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms transfer
end TNLean.PEPS.PairEffect.PartyGate

namespace TNLean.PEPS.PairEffect
#print axioms gate_toGate_eq_sum
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect.PartyChain
#print axioms comp
end TNLean.PEPS.PairEffect.PartyChain

namespace TNLean.PEPS.PairEffect.PartyChain
#print axioms effectCount_comp
end TNLean.PEPS.PairEffect.PartyChain

namespace TNLean.PEPS.PairEffect.PartyChain
#print axioms effectCount_prependWord
end TNLean.PEPS.PairEffect.PartyChain

namespace TNLean.PEPS.PairEffect.PartyChain
#print axioms eval_comp
end TNLean.PEPS.PairEffect.PartyChain

namespace TNLean.PEPS.PairEffect.PartyChain
#print axioms eval_prependWord
end TNLean.PEPS.PairEffect.PartyChain

namespace TNLean.PEPS.PairEffect.PartyChain
#print axioms isAllowed_comp
end TNLean.PEPS.PairEffect.PartyChain

namespace TNLean.PEPS.PairEffect.PartyChain
#print axioms isAllowed_prependWord
end TNLean.PEPS.PairEffect.PartyChain

namespace TNLean.PEPS.PairEffect.PartyChain
#print axioms prependWord
end TNLean.PEPS.PairEffect.PartyChain

namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms comp
end TNLean.PEPS.PairEffect.PartyGate

namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms effectCount_comp_le
end TNLean.PEPS.PairEffect.PartyGate

namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms gate_comp
end TNLean.PEPS.PairEffect.PartyGate

namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms isAllowed_comp
end TNLean.PEPS.PairEffect.PartyGate

namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms length_comp
end TNLean.PEPS.PairEffect.PartyGate

namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms mem_comp
end TNLean.PEPS.PairEffect.PartyGate

namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms sum_norm_comp
end TNLean.PEPS.PairEffect.PartyGate

namespace TNLean.PEPS.PairEffect
#print axioms MessageMonomial
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect.MessageMonomial
#print axioms IsAllowed
end TNLean.PEPS.PairEffect.MessageMonomial

namespace TNLean.PEPS.PairEffect.MessageMonomial
#print axioms effectCount
end TNLean.PEPS.PairEffect.MessageMonomial

namespace TNLean.PEPS.PairEffect.MessageMonomial
#print axioms eval
end TNLean.PEPS.PairEffect.MessageMonomial

namespace TNLean.PEPS.PairEffect.MessageMonomial
#print axioms eval_expand
end TNLean.PEPS.PairEffect.MessageMonomial

namespace TNLean.PEPS.PairEffect.MessageMonomial
#print axioms expand
end TNLean.PEPS.PairEffect.MessageMonomial

namespace TNLean.PEPS.PairEffect.MessageMonomial
#print axioms expansion_size
end TNLean.PEPS.PairEffect.MessageMonomial

namespace TNLean.PEPS.PairEffect.MessageMonomial
#print axioms expansion_size_le
end TNLean.PEPS.PairEffect.MessageMonomial

namespace TNLean.PEPS.PairEffect.MessageMonomial
#print axioms expansion_size_le_of_power_bounds
end TNLean.PEPS.PairEffect.MessageMonomial

namespace TNLean.PEPS.PairEffect.MessageMonomial
#print axioms isAllowed_effectCount_expand
end TNLean.PEPS.PairEffect.MessageMonomial

namespace TNLean.PEPS.PairEffect.MessageMonomial
#print axioms messageDimensions
end TNLean.PEPS.PairEffect.MessageMonomial

namespace TNLean.PEPS.PairEffect
#print axioms MessageGate
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms effectCount_expand_le
end TNLean.PEPS.PairEffect.MessageGate

namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms eval
end TNLean.PEPS.PairEffect.MessageGate

namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms eval_expand
end TNLean.PEPS.PairEffect.MessageGate

namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms expand
end TNLean.PEPS.PairEffect.MessageGate

namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms expansion_size
end TNLean.PEPS.PairEffect.MessageGate

namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms expansion_size_le
end TNLean.PEPS.PairEffect.MessageGate

namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms expansion_size_le_of_coeff_le
end TNLean.PEPS.PairEffect.MessageGate

namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms isAllowed_expand
end TNLean.PEPS.PairEffect.MessageGate

namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms mem_expand
end TNLean.PEPS.PairEffect.MessageGate

namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms eval_toOriginalCircuit
end TNLean.PEPS.PairEffect.MessageGate

namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms isExpansionBounded_toOriginalCircuit
end TNLean.PEPS.PairEffect.MessageGate

namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms isMonomialBounded_toOriginalCircuit
end TNLean.PEPS.PairEffect.MessageGate

namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms nonprivateCount_toOriginalCircuit
end TNLean.PEPS.PairEffect.MessageGate

namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms participants_toOriginalCircuit
end TNLean.PEPS.PairEffect.MessageGate

namespace TNLean.PEPS.PairEffect.MessageGate
#print axioms toOriginalCircuit
end TNLean.PEPS.PairEffect.MessageGate

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms card_sourceNetworkAlphabet_le_of_power_bounds
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.ProductInput
#print axioms finiteDimensional_wholePartyMem
end TNLean.PEPS.PairEffect.ProductInput

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms card_branchLabels_physicalFirstReplacement_le_power
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms card_sourceLocations_physicalFirstReplacement_le
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms sourceSamplingCount_physicalFirstReplacement_lt_power
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms card_incidentPhysicalFirstLinks_le
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms exists_original_gate_of_physicalFirst_link
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms participants_physicalFirstReplacementLocationsEquiv
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms physicalFirstReplacementLocationsEquiv
end TNLean.PEPS.PairEffect.OriginalCircuit

run_cmd do
  let e ← Lean.getEnv
  let ns := e.header.moduleNames.map (fun n ↦ Lean.Json.str n.toString)
  IO.FS.writeFile "imported-modules.json" (Lean.Json.compress (Lean.Json.arr ns))
