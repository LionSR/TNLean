import TNLean.PEPS.Approximation.CommonSourceGate
import TNLean.PEPS.Approximation.FiniteSourceGate

/-! Focused checks for empty branch families and unequal branch halfspaces. -/

noncomputable section
open scoped InnerProductSpace TensorProduct
open ContinuousLinearMap
namespace TNLean.PEPS.PairEffect.Regression

/-- Pair slots are constructed even when no branch is available to supply a reference list. -/
theorem empty_family_has_pair_slot :
    ∃ R : SourceInventory Bool, (R.map PairSource.partyPair).Nodup ∧
      s(false, true) ∈ R.map PairSource.partyPair := by
  obtain ⟨R, hR, hK, _⟩ := Word.exists_finite_source_preparation
    (fun ξ : Empty ↦ ξ.elim : Empty → Word ([] : Layout Bool) []) (fun ξ ↦ ξ.elim)
  refine ⟨R, hR, (hK _).mpr ?_⟩
  simp [Sym2.mk_isDiag_iff]

/-- One branch has a one-dimensional left halfspace and the other has two dimensions. -/
def branchSpace : Bool → HSpace
  | false => HSpace.of ℂ
  | true => HSpace.of (EuclideanSpace ℂ (Fin 2))

def branchVector : ∀ ξ, branchSpace ξ
  | false => Complex.I
  | true => PiLp.single 2 (0 : Fin 2) 1

theorem branchVector_norm (ξ : Bool) : ‖branchVector ξ‖ = 1 := by
  cases ξ
  · exact Complex.norm_I
  · exact (PiLp.norm_single 2 (fun _ : Fin 2 ↦ ℂ) 0 1).trans norm_one

/-- The second branch sector is annihilated by projection onto the first. -/
theorem unequal_sectors_are_separate :
    PairSource.commonProjection branchSpace false
      (PairSource.commonInclusion branchSpace true (branchVector true)) = 0 := by
  let : DecidableEq Bool := Classical.decEq Bool
  exact PiLp.single_eq_of_ne (β := fun ξ ↦ (branchSpace ξ).carrier) 2
    (Bool.false_ne_true) (branchVector true)

/-- Recovery retains the phase of the original source in the one-dimensional branch. -/
theorem phase_is_recovered :
    PairSource.commonProjection branchSpace false
      (PairSource.commonInclusion branchSpace false (branchVector false)) = Complex.I := by
  exact PairSource.commonProjection_commonInclusion branchSpace false (branchVector false)

/-- The two branches have different left dimensions and a nonreal source phase. -/
def branchSource (ξ : Bool) : branchSpace ξ ⊗[ℂ] HSpace.of ℂ :=
  branchVector ξ ⊗ₜ[ℂ] (1 : ℂ)

theorem branchSource_norm (ξ : Bool) : ‖branchSource ξ‖ = 1 := by
  exact (TensorProduct.norm_tmul (branchVector ξ) (1 : ℂ)).trans (by
    rw [branchVector_norm, norm_one, mul_one])

/-- Passing to common spaces preserves normalization for both unequal-dimensional branches. -/
theorem common_sources_normalized (ξ : Bool) :
    ‖PairSource.commonVector branchSpace (fun _ ↦ HSpace.of ℂ) branchSource ξ‖ = 1 := by
  exact (PairSource.norm_commonVector _ _ _ _).trans (branchSource_norm ξ)

/-- The full two-sided recovery retains the source phase, rather than only its norm. -/
theorem source_phase_is_recovered :
    TensorProduct.mapL (PairSource.commonProjection branchSpace false)
      (PairSource.commonProjection (fun _ : Bool ↦ HSpace.of ℂ) false)
      (PairSource.commonVector branchSpace (fun _ ↦ HSpace.of ℂ) branchSource false) =
        Complex.I ⊗ₜ[ℂ] (1 : ℂ) := by
  exact PairSource.mapL_commonProjection_commonVector _ _ branchSource false

end TNLean.PEPS.PairEffect.Regression
