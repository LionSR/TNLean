import CommonSourceRegression

set_option linter.hashCommand false

#print axioms TNLean.PEPS.PairEffect.Regression.empty_family_has_pair_slot
#print axioms TNLean.PEPS.PairEffect.Regression.branchVector_norm
#print axioms TNLean.PEPS.PairEffect.Regression.unequal_sectors_are_separate
#print axioms TNLean.PEPS.PairEffect.Regression.phase_is_recovered
#print axioms TNLean.PEPS.PairEffect.Regression.branchSource_norm
#print axioms TNLean.PEPS.PairEffect.Regression.common_sources_normalized
#print axioms TNLean.PEPS.PairEffect.Regression.source_phase_is_recovered
