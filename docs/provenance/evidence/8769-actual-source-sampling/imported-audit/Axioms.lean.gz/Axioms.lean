import TNLean

/-! Imported axiom check of the new source identities and refactored declarations. -/
set_option linter.hashCommand false

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms integrable_actualGaussianBranch_and_integral_le
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect
#print axioms exteriorFamilyPhysicalBasis
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms finrank_exteriorFamilyPhysicalLayout
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect.Layout
#print axioms finiteDimensional_mem_of_registers
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.Layout
#print axioms finiteDimensional_mem_restrict_mapOwner_mapOwner
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.Layout
#print axioms restrictedDiscardBasis
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms exists_sampledSourceMatrix_error_le_of_integral_bound
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.Approximation
#print axioms sourceSamplingCount_lt_inv_pow
end TNLean.PEPS.Approximation

namespace TNLean.PEPS.Approximation
#print axioms sourceSamplingCount_lt_of_gate_power_bounds
end TNLean.PEPS.Approximation

namespace TNLean.PEPS.Approximation
#print axioms sourceSamplingCount_lt_of_power_bounds
end TNLean.PEPS.Approximation

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms integral_actualCorrectedSourceTerm_le
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms integral_actualCorrectedSourceTerm_le_lifetime
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms exists_sourceSample_lifetime_error_le
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms exists_sourceSample_polynomial_error_le
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms card_branchLabels_replacement_le_power
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect
#print axioms replacementMonomialBound_le_of_power_bounds
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms stackLength_sourceGateBudget_eq
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms stackLength_sourceGateBudget_lt_of_power_bounds
end TNLean.PEPS.PairEffect

run_cmd do
  let e ← Lean.getEnv
  let ns := e.header.moduleNames.map (fun n ↦ Lean.Json.str n.toString)
  IO.FS.writeFile "imported-modules.json" (Lean.Json.compress (Lean.Json.arr ns))
