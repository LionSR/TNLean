import TNLean.PEPS.Approximation.ApproximateCircuitBudget

set_option linter.hashCommand false
namespace TNLean.PEPS.PairEffect
#print axioms inversePower_le_sourceGateBudget_half
end TNLean.PEPS.PairEffect
namespace TNLean.PEPS.PairEffect.EffectCircuit.IsGateApproximation
#print axioms mono
end TNLean.PEPS.PairEffect.EffectCircuit.IsGateApproximation
namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms isGateApproximation_budget_of_power_bound
end TNLean.PEPS.PairEffect.EffectCircuit

run_cmd do
  let environment ← Lean.getEnv
  let names := environment.header.moduleNames.map (fun n ↦ Lean.Json.str n.toString)
  IO.FS.writeFile "imported-modules.json" (Lean.Json.compress (Lean.Json.arr names))
