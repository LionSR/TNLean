import TNLean.PEPS.Approximation.DistributedConstruction

set_option linter.hashCommand false
namespace TNLean.PEPS.PairEffect
#print axioms DistributedConstruction
end TNLean.PEPS.PairEffect
namespace TNLean.PEPS.PairEffect.DistributedConstruction
#print axioms input
end TNLean.PEPS.PairEffect.DistributedConstruction
namespace TNLean.PEPS.PairEffect.DistributedConstruction
#print axioms physicalDensity
end TNLean.PEPS.PairEffect.DistributedConstruction
namespace TNLean.PEPS.PairEffect.DistributedConstruction
#print axioms physicalDensity_posSemidef
end TNLean.PEPS.PairEffect.DistributedConstruction
namespace TNLean.PEPS.PairEffect.DistributedConstruction
#print axioms trace_physicalDensity_le_one
end TNLean.PEPS.PairEffect.DistributedConstruction

run_cmd do
  let environment ← Lean.getEnv
  let names := environment.header.moduleNames.map (fun n ↦ Lean.Json.str n.toString)
  IO.FS.writeFile "../final-verification-20261008/imported-modules.json"
    (Lean.Json.compress (Lean.Json.arr names))
