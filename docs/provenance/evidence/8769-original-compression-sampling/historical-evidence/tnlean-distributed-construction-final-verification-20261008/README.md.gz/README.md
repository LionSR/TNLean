# Distributed constructions and their physical density

The five explicit declarations bundle only original circuit data, construct the actual normalized product input, define the original physical density by the final private-register trace, and prove its positivity and trace bound of one. The original party memories and discarded output registers are finite-dimensional, with no numerical private-dimension bound. Intermediate circuit spaces remain as general as the existing circuit syntax.

The source-facing record has one nonempty-party field. The accompanying one-page Local fix note explains the scalar obstruction at zero parties and the source proof's absorption of scalars at an existing party. Generic circuits and empty-participant gates remain unchanged. No literal zero-party approximation theorem, compressed representation, numerical resource bound, or error conclusion is assumed or proved here.

Strict raw Lean checking used all package options and warningAsError: 7.331 seconds, zero diagnostics. The imported audit checked all five explicit declarations and reports only propext, Classical.choice, and Quot.sound. All 4,956 imported artifacts were hashed and rehashed unchanged. Sources and outputs were confined to this scratch prefix; the canonical dependency environment is the frozen 65-name message-resource contribution. No Lake build or cache mutation was performed.

The definition and convention were independently reviewed by the root and PEPS agents. The PEPS agent also independently reviewed the final positivity and trace-bound proofs. The final note renders on one page, has no overfull boxes, and was visually inspected. The blueprint fragment covers all five public declarations and cites the supplied gap bibliography entry; full chapter integration and validation belong to canonical adoption.

This is a scratch handoff, with no new production source revision. Exact build/audit commands, source and artifact hashes, dependency hashes, note source/render, and blueprint fragment are retained beside this report.
