from pathlib import Path
import json,os,subprocess,time,hashlib,sys
b=Path('/private/tmp/tnlean-distributed-construction');cfg=json.load(open(b/'env.json'));module=sys.argv[1]
p=b/'src/TNLean/PEPS/Approximation'/(module+'.lean');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((Path('/tmp')/(module+'.lean')).read_bytes())
out=b/'TNLean/PEPS/Approximation'/(module+'.olean');assert not out.is_symlink()
env=os.environ.copy();env['LEAN_PATH']=cfg['LEAN_PATH'];cmd=[cfg['lean'],*cfg['options'],'-DwarningAsError=true','-o',str(out),str(p)];t=time.monotonic();r=subprocess.run(cmd,cwd=b/'src',env=env,text=True,capture_output=True)
(b/(module+'.log')).write_text(r.stdout+r.stderr)
(b/(module+'-command.json')).write_text(json.dumps({'command':cmd,'cwd':str(b/'src'),'LEAN_PATH':env['LEAN_PATH'],'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'artifact_sha256':hashlib.sha256(out.read_bytes()).hexdigest() if out.exists() else None,'returncode':r.returncode,'seconds':time.monotonic()-t},indent=2)+'\n')
print(r.stdout+r.stderr);print(module,r.returncode,time.monotonic()-t,flush=True);raise SystemExit(r.returncode)
