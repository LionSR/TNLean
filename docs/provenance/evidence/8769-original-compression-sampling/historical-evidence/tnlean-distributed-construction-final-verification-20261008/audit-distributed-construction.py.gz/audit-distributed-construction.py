from pathlib import Path
import json,os,subprocess,time,hashlib,re
base=Path('/private/tmp/tnlean-distributed-construction');b=base/'final-verification-20261008';b.mkdir(exist_ok=True)
cfg=json.load(open(base/'env.json'));env=os.environ.copy();env['LEAN_PATH']=cfg['LEAN_PATH'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
mods=['DistributedConstruction'];manifest=[];records=[]
for m in mods:
 src=Path('/tmp')/(m+'.lean');cp=base/'src/TNLean/PEPS/Approximation'/(m+'.lean');out=base/'TNLean/PEPS/Approximation'/(m+'.olean');rec=json.load(open(base/(m+'-command.json')))
 assert src.read_bytes()==cp.read_bytes() and sha(src)==rec['source_sha256'] and sha(out)==rec['artifact_sha256'] and rec['returncode']==0
 rec.update(module='TNLean.PEPS.Approximation.'+m,source_path=str(src),checked_source_path=str(cp),artifact_path=str(out));records.append(rec)
 (b/(m+'.log')).write_bytes((base/(m+'.log')).read_bytes());(b/(m+'-command.json')).write_text(json.dumps(rec,indent=2)+'\n')
 ns=[]
 for line in src.read_text().splitlines():
  mt=re.match(r'namespace (\S+)\s*$',line)
  if mt:ns.append(mt[1])
  if line.startswith('end '):ns.pop()
  mt=re.match(r'(?:@\[[^]]+\] )?(?:structure|def|theorem|lemma) ([\w.\u0080-\uffff]+)',line)
  if mt:
   full='.'.join(ns+[mt[1]]);namespace,name=full.rsplit('.',1)
   manifest.append(dict(module=rec['module'],namespace=namespace,name=name,declaration=full))
(b/'build-records.json').write_text(json.dumps(records,indent=2)+'\n');(b/'declarations.json').write_text(json.dumps(manifest,indent=2)+'\n')
audit=b/'DistributedConstructionAudit.lean';s='import TNLean.PEPS.Approximation.DistributedConstruction\n\nset_option linter.hashCommand false\n'
for e in manifest:s+='namespace '+e['namespace']+'\n#print axioms '+e['name']+'\nend '+e['namespace']+'\n'
s+='''\nrun_cmd do
  let environment ← Lean.getEnv
  let names := environment.header.moduleNames.map (fun n ↦ Lean.Json.str n.toString)
  IO.FS.writeFile "../final-verification-20261008/imported-modules.json"
    (Lean.Json.compress (Lean.Json.arr names))
''';audit.write_text(s)
cmd=[cfg['lean'],*cfg['options'],'-DwarningAsError=true',str(audit)];t=time.monotonic();r=subprocess.run(cmd,cwd=base/'src',env=env,text=True,capture_output=True)
(b/'audit.log').write_text(r.stdout+r.stderr);(b/'audit-command.json').write_text(json.dumps(dict(command=cmd,cwd=str(base/'src'),LEAN_PATH=env['LEAN_PATH'],source_sha256=sha(audit),returncode=r.returncode,seconds=time.monotonic()-t),indent=2)+'\n');print(r.stdout+r.stderr,flush=True);assert r.returncode==0
for e in manifest:
 name=e['declaration'];m=re.search(r"'"+re.escape(name)+r"' depends on axioms: \[([^\]]*)\]",r.stdout,re.S)
 if m:assert set(x.strip() for x in m[1].split(',') if x.strip()) <= {'propext','Classical.choice','Quot.sound'}
 else:assert "'"+name+"' does not depend on any axioms" in r.stdout
roots=list(map(Path,env['LEAN_PATH'].split(':')));deps=[]
for m in json.loads((b/'imported-modules.json').read_text()):
 rel=m.replace('.','/')+'.olean';p=next((rt/rel for rt in roots if (rt/rel).is_file()),None);assert p,m
 deps.append(dict(module=m,path=str(p),resolved_path=str(p.resolve()),sha256=sha(p)))
(b/'imported-dependencies.json').write_text(json.dumps(deps,indent=2)+'\n')
(b/'checked-sources.json').write_text(json.dumps(dict(modules=records,public_declarations=manifest,imported_artifact_count=len(deps),imported_dependencies_sha256=sha(b/'imported-dependencies.json'),source_revision=None,canonical_dependency_environment='/private/tmp/tnlean-message-resource-bounds/env.json'),indent=2)+'\n')
print(len(manifest),len(deps),str(b),flush=True)
