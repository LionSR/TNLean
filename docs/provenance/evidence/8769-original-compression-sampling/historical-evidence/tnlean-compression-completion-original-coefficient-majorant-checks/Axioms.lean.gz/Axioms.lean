import TNLean.PEPS.Approximation.OriginalCoefficientMajorant

set_option linter.hashCommand false
namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms exists_one_le_isExpansionBounded_of_termwise_power_bounds
end TNLean.PEPS.PairEffect.OriginalCircuit

run_cmd do
  let environment ← Lean.getEnv
  let names := environment.header.moduleNames.map (fun n ↦ Lean.Json.str n.toString)
  IO.FS.writeFile "imported-modules.json" (Lean.Json.compress (Lean.Json.arr names))
