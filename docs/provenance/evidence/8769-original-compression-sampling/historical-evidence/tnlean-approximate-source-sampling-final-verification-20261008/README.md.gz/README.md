# Sampling from actual approximate original gates

The theorem compares the constructed sampled physical operator with the density of the original gate-map family G. The same chronology separately records the actual approximate monomial sums. The sole local error premise uses sourceGateBudget(ε/2,M), which reserves ε/4 for the approximation. Rescaling produces an actual OriginalCircuit; its count, participant lifetime, pair-effect bound and coefficient sum are derived. The relay theorem then constructs the effect replacement, actual Schmidt data and Gaussian sample with the remaining 3ε/4 bound. The final triangle inequality gives total error ε.

The input orthonormal basis is constructed from finite-dimensionality of each original party memory. Every private register is finite-dimensional, as required by the manuscript; there is no numerical bound on its dimension, no nontriviality or nonempty-party premise, no given global approximation estimate and no given Schmidt decomposition. The result is an actual sampled-operator comparison. The later local tensor-network contraction and uniform-family theorem remain separate.

Source: polynomial-PEPS Theorem5.2, 04-compression.tex, lines17–19,137–175,199–229 and590–600.

## Exact verification

The separate temporary prefix extends the frozen75 canonical environment. The relay source is translated only at its two imports; the exact translation and hashes are recorded. FiniteInputMemory is recompiled unchanged over this closure. All three modules pass package options with warningAsError. All six public declarations in the imported audit use only propext, Classical.choice and Quot.sound; all5,485 actually imported artifacts are hashed. No cache, predecessor artifact or repository source is modified.

- TNLean.PEPS.Approximation.FiniteInputMemory: strict 4.780s; source SHA-256 3555d79ab8f2c9b66e51e6ca0ba2b0881dcca88683ad67d6cde13443d8f485f3.
- TNLean.PEPS.Approximation.SampledOriginalCircuit: strict 5.775s; source SHA-256 de41e21740168642951d22e13b3ce040222c37ab3683b20997573819127e0bf2.
- TNLean.PEPS.Approximation.ApproximateSourceSampling: strict 6.945s; source SHA-256 f975342afe2f9c13388617fa4054d3e9457a825fe872bd35bb9584e8a7091daa.
- Imported audit: 12.657s.
