import TNLean.PEPS.Approximation.ApproximateSourceSampling

set_option linter.hashCommand false
namespace TNLean.PEPS.PairEffect.ProductInput
#print axioms finiteDimensional_wholePartyMem
end TNLean.PEPS.PairEffect.ProductInput
namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms isMonomialBounded_mono
end TNLean.PEPS.PairEffect.OriginalCircuit
namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms exists_isMonomialBounded
end TNLean.PEPS.PairEffect.OriginalCircuit
namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms sum_norm_branchCoefficient_physicalFirstReplacement_le
end TNLean.PEPS.PairEffect.OriginalCircuit
namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms exists_physicalFirst_sourceSample_original_error_le
end TNLean.PEPS.PairEffect.OriginalCircuit
namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms exists_sourceSample_approximate_error_le
end TNLean.PEPS.PairEffect.EffectCircuit

run_cmd do
  let environment ← Lean.getEnv
  let names := environment.header.moduleNames.map (fun n ↦ Lean.Json.str n.toString)
  IO.FS.writeFile "../final-verification-20261008/imported-modules.json"
    (Lean.Json.compress (Lean.Json.arr names))
