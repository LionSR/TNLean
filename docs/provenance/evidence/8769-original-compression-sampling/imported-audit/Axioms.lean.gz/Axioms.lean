import TNLean

/-! Imported axiom check of the original-circuit sampling declarations. -/
set_option linter.hashCommand false

namespace TNLean.PEPS.PairEffect.EffectCircuit.IsGateApproximation
#print axioms mono
end TNLean.PEPS.PairEffect.EffectCircuit.IsGateApproximation

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms isGateApproximation_budget_of_power_bound
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect
#print axioms inversePower_le_sourceGateBudget_half
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms exists_isMonomialBounded
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms exists_physicalFirst_sourceSample_original_error_le
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms isMonomialBounded_mono
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms sum_norm_branchCoefficient_physicalFirstReplacement_le
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms exists_sourceSample_approximate_error_le
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms card_physicalFirstNetworkAlphabet_le_power
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms exists_one_le_isExpansionBounded_of_termwise_power_bounds
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect
#print axioms DistributedConstruction
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect.DistributedConstruction
#print axioms input
end TNLean.PEPS.PairEffect.DistributedConstruction

namespace TNLean.PEPS.PairEffect.DistributedConstruction
#print axioms physicalDensity
end TNLean.PEPS.PairEffect.DistributedConstruction

namespace TNLean.PEPS.PairEffect.DistributedConstruction
#print axioms physicalDensity_posSemidef
end TNLean.PEPS.PairEffect.DistributedConstruction

namespace TNLean.PEPS.PairEffect.DistributedConstruction
#print axioms trace_physicalDensity_le_one
end TNLean.PEPS.PairEffect.DistributedConstruction

run_cmd do
  let e ← Lean.getEnv
  let ns := e.header.moduleNames.map (fun n ↦ Lean.Json.str n.toString)
  IO.FS.writeFile "imported-modules.json" (Lean.Json.compress (Lean.Json.arr ns))
