import TNLean

/-! Imported axiom check of the new source identities and refactored declarations. -/
set_option linter.hashCommand false

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms GateMaps
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms IsGateApproximation
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms evalWithGateMaps
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms norm_evalWithGateMaps_le_one
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms rescaledOriginal
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect
#print axioms gate_rescalePartyGate
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms isAllowed_rescalePartyGate
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms monomials_rescalePartyGate
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms rescalePartyGate
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms sum_norm_rescalePartyGate_le
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms isExpansionBounded_rescaledOriginal
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms isMonomialBounded_rescaledOriginal
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms monomialCount
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms nonprivateCount_rescaledOriginal
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms participants_rescaledOriginal
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms participationCount_rescaledOriginal
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms rescaledLocationsEquiv
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms norm_rescaledOriginal_sub_evalWithGateMaps_le
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms norm_eval_le_one
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms physicalDensityWithGateMaps
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms rectangularTraceNorm_rescaledOriginal_density_sub_le
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms rectangularTraceNorm_rescaledOriginal_density_sub_le_budget
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms rectangularTraceNorm_rescaledOriginal_density_sub_le_inv_pow
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect
#print axioms gateApproximation_error_inv_pow_le
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms rectangularTraceNorm_rescaledOriginal_density_sub_le_real_pow
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect
#print axioms gateApproximation_error_real_pow_le
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms IsTermwiseBounded
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms isExpansionBounded_of_isTermwiseBounded
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms isExpansionBounded_of_termwise_power_bounds
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms sum_norm_coefficients_le
end TNLean.PEPS.PairEffect.PartyGate

namespace TNLean.PEPS.PairEffect.PartyGate
#print axioms sum_norm_coefficients_le_of_power_bounds
end TNLean.PEPS.PairEffect.PartyGate

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms finiteDimensional_auxiliary_private_mem
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms finiteDimensional_auxiliary_private_registers
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms finiteDimensional_auxiliary_registers
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.Layout
#print axioms finiteDimensional_registers_append
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.Layout
#print axioms finiteDimensional_registers_mapOwner
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.PartyChain
#print axioms finiteDimensional_registers_sources_prepStack
end TNLean.PEPS.PairEffect.PartyChain

namespace TNLean.PEPS.PairEffect
#print axioms finiteDimensional_registers_sources_comp
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms finiteDimensional_registers_sources_prepGate
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms finiteDimensional_registers_sources_prepWord
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms physicalDensity_pure_input
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms branchCoefficient_physicalFirstLocationsEquiv
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms branchLabels_physicalFirstLocationsEquiv
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms card_gateLocations_physicalFirstOutput
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms card_sourceLocations_physicalFirstOutput
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms endpoints_physicalFirstSourcesEquiv
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms eval_exchangeBlocks_operator
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms eval_exchangeBlocks_threeFactors
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms eval_exchangeBlocks_triple_tmul
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms isAllowed_physicalFirstOutput
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms isExpansionBounded_physicalFirstOutput
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms participants_physicalFirstLocationsEquiv
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms participationCount_physicalFirstOutput
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms physicalFirstLocationsEquiv
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms physicalFirstOutput
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms physicalFirstParticipationEquiv
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms physicalFirstSourcesEquiv
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms slotCount_physicalFirstLocationsEquiv
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms sourceDims_physicalFirstSourcesEquiv
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms sourceOrder_exchangeBlocks
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms sourceOrder_physicalFirstOutput
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms sourceVectorAt_physicalFirstSourcesEquiv
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms physicalDensity_physicalFirstReplacement
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms physicalFirstReplacement
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms physicalSourceReplacedDensity_physicalFirstReplacement_exact
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms rectangularTraceNorm_physicalFirst_density_sub_le_half
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms physicalDensity_physicalFirstOutput
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect
#print axioms exchangedGarbageBasis
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms extendedPhysicalReadout_triple_tmul
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms partialTrace_physicalFirstReadout_exchange
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms physicalFirstReadout
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms physicalFirstReadout_exchange_apply
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms physicalFirstReadout_exchange_outerProduct
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms physicalFirstReadout_tmul
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms norm_comp_sub_comp_le_one
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms norm_referenceEval_le_one
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms norm_replacement_sub_reference_le
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms referenceEval
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms referenceEval_apply
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms exchangeHead_tmul
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms norm_eval_castLayouts_sub
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect
#print axioms appendIso_singleton_symm_tmul
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms gateMemoryMap_auxiliary_identity
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms gateMemoryMap_auxiliary_tmul
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms gateMemoryMap_tmul
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms preparation_mapOwner_heq
end TNLean.PEPS.PairEffect

run_cmd do
  let e ← Lean.getEnv
  let ns := e.header.moduleNames.map (fun n ↦ Lean.Json.str n.toString)
  IO.FS.writeFile "imported-modules.json" (Lean.Json.compress (Lean.Json.arr ns))
