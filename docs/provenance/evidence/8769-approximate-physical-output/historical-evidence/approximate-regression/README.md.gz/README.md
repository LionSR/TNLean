# Actual noncontractive scalar-gate regression

The approximate gate is the literal one-term monomial expansion 2 times the identity on an empty participant set. Its operator norm is proved to equal 2, so contractivity of the raw approximate sum is not silently assumed. The original target is the identity, and the actual local approximation conditions hold with delta=1. Rescaling by (1+delta)^(-1) is proved to give exactly the identity. Composing the same gate twice retains two distinct chronological occurrences. This also tests the manuscript convention permitting empty nonprivate participant sets.

All four regression declarations strictly export at the package options with warningAsError, and all four imported axiom reports use only the standard axioms. The main proof sources are unchanged; their exact hashes are recorded in the adjacent final-verification-20261008 directory. The regression closure hashes 4,965 actual imported artifacts.
