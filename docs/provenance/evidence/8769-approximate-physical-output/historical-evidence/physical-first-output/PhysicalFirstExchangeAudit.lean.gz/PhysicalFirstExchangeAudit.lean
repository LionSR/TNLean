import TNLeanRelayOutput.PhysicalFirstExchange

/-! # Stock axiom audit of all public declarations -/

set_option linter.hashCommand false in
#print axioms TNLean.PEPS.PairEffect.SourceCircuit.eval_exchangeBlocks_triple_tmul

set_option linter.hashCommand false in
#print axioms TNLean.PEPS.PairEffect.SourceCircuit.eval_exchangeBlocks_threeFactors

set_option linter.hashCommand false in
#print axioms TNLean.PEPS.PairEffect.SourceCircuit.eval_exchangeBlocks_operator

set_option linter.hashCommand false in
#print axioms TNLean.PEPS.PairEffect.SourceCircuit.physicalFirstOutput

set_option linter.hashCommand false in
#print axioms TNLean.PEPS.PairEffect.SourceCircuit.isAllowed_physicalFirstOutput

set_option linter.hashCommand false in
#print axioms TNLean.PEPS.PairEffect.SourceCircuit.physicalFirstLocationsEquiv

set_option linter.hashCommand false in
#print axioms TNLean.PEPS.PairEffect.SourceCircuit.physicalFirstSourcesEquiv

set_option linter.hashCommand false in
#print axioms TNLean.PEPS.PairEffect.SourceCircuit.participants_physicalFirstLocationsEquiv

set_option linter.hashCommand false in
#print axioms TNLean.PEPS.PairEffect.SourceCircuit.slotCount_physicalFirstLocationsEquiv

set_option linter.hashCommand false in
#print axioms TNLean.PEPS.PairEffect.SourceCircuit.branchLabels_physicalFirstLocationsEquiv

set_option linter.hashCommand false in
#print axioms TNLean.PEPS.PairEffect.SourceCircuit.branchCoefficient_physicalFirstLocationsEquiv

set_option linter.hashCommand false in
#print axioms TNLean.PEPS.PairEffect.SourceCircuit.endpoints_physicalFirstSourcesEquiv

set_option linter.hashCommand false in
#print axioms TNLean.PEPS.PairEffect.SourceCircuit.sourceDims_physicalFirstSourcesEquiv

set_option linter.hashCommand false in
#print axioms TNLean.PEPS.PairEffect.SourceCircuit.sourceVectorAt_physicalFirstSourcesEquiv

set_option linter.hashCommand false in
#print axioms TNLean.PEPS.PairEffect.SourceCircuit.sourceOrder_exchangeBlocks

set_option linter.hashCommand false in
#print axioms TNLean.PEPS.PairEffect.SourceCircuit.sourceOrder_physicalFirstOutput

set_option linter.hashCommand false in
#print axioms TNLean.PEPS.PairEffect.SourceCircuit.card_gateLocations_physicalFirstOutput

set_option linter.hashCommand false in
#print axioms TNLean.PEPS.PairEffect.SourceCircuit.card_sourceLocations_physicalFirstOutput

set_option linter.hashCommand false in
#print axioms TNLean.PEPS.PairEffect.SourceCircuit.physicalFirstParticipationEquiv

set_option linter.hashCommand false in
#print axioms TNLean.PEPS.PairEffect.SourceCircuit.participationCount_physicalFirstOutput

set_option linter.hashCommand false in
#print axioms TNLean.PEPS.PairEffect.SourceCircuit.isExpansionBounded_physicalFirstOutput
