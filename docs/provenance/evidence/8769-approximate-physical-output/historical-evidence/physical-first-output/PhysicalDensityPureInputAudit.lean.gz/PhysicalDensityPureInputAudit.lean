import TNLeanRelayOutput.PhysicalDensityPureInput

/-! # Stock axiom audit of all public declarations -/

set_option linter.hashCommand false in
#print axioms TNLean.PEPS.PairEffect.SourceCircuit.physicalDensity_pure_input
