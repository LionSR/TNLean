import TNLeanRelayOutput.PhysicalFirstReadout

set_option linter.hashCommand false in
#print axioms
  TNLean.PEPS.PairEffect.exchangedGarbageBasis
set_option linter.hashCommand false in
#print axioms
  TNLean.PEPS.PairEffect.physicalFirstReadout
set_option linter.hashCommand false in
#print axioms
  TNLean.PEPS.PairEffect.physicalFirstReadout_tmul
set_option linter.hashCommand false in
#print axioms
  TNLean.PEPS.PairEffect.extendedPhysicalReadout_triple_tmul
set_option linter.hashCommand false in
#print axioms
  TNLean.PEPS.PairEffect.physicalFirstReadout_exchange_apply
set_option linter.hashCommand false in
#print axioms
  TNLean.PEPS.PairEffect.physicalFirstReadout_exchange_outerProduct
set_option linter.hashCommand false in
#print axioms
  TNLean.PEPS.PairEffect.partialTrace_physicalFirstReadout_exchange
set_option linter.hashCommand false in
#print axioms
  TNLean.PEPS.PairEffect.SourceCircuit.physicalDensity_physicalFirstOutput
set_option linter.hashCommand false in
#print axioms
  TNLean.PEPS.PairEffect.EffectCircuit.physicalFirstReplacement
set_option linter.hashCommand false in
#print axioms
  TNLean.PEPS.PairEffect.EffectCircuit.physicalDensity_physicalFirstReplacement
set_option linter.hashCommand false in
#print axioms
  TNLean.PEPS.PairEffect.EffectCircuit.physicalSourceReplacedDensity_physicalFirstReplacement_exact
set_option linter.hashCommand false in
#print axioms
  TNLean.PEPS.PairEffect.OriginalCircuit.rectangularTraceNorm_physicalFirst_density_sub_le_half
