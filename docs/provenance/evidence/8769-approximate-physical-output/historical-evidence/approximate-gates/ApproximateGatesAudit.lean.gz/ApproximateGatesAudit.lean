import TNLean.PEPS.Approximation.ApproximateCircuitPolynomial

set_option linter.hashCommand false
namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms GateMaps
end TNLean.PEPS.PairEffect.EffectCircuit
namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms evalWithGateMaps
end TNLean.PEPS.PairEffect.EffectCircuit
namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms IsGateApproximation
end TNLean.PEPS.PairEffect.EffectCircuit
namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms norm_evalWithGateMaps_le_one
end TNLean.PEPS.PairEffect.EffectCircuit
namespace TNLean.PEPS.PairEffect
#print axioms rescalePartyGate
end TNLean.PEPS.PairEffect
namespace TNLean.PEPS.PairEffect
#print axioms monomials_rescalePartyGate
end TNLean.PEPS.PairEffect
namespace TNLean.PEPS.PairEffect
#print axioms gate_rescalePartyGate
end TNLean.PEPS.PairEffect
namespace TNLean.PEPS.PairEffect
#print axioms sum_norm_rescalePartyGate_le
end TNLean.PEPS.PairEffect
namespace TNLean.PEPS.PairEffect
#print axioms isAllowed_rescalePartyGate
end TNLean.PEPS.PairEffect
namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms rescaledOriginal
end TNLean.PEPS.PairEffect.EffectCircuit
namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms rescaledLocationsEquiv
end TNLean.PEPS.PairEffect.EffectCircuit
namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms nonprivateCount_rescaledOriginal
end TNLean.PEPS.PairEffect.EffectCircuit
namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms participants_rescaledOriginal
end TNLean.PEPS.PairEffect.EffectCircuit
namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms participationCount_rescaledOriginal
end TNLean.PEPS.PairEffect.EffectCircuit
namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms isExpansionBounded_rescaledOriginal
end TNLean.PEPS.PairEffect.EffectCircuit
namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms monomialCount
end TNLean.PEPS.PairEffect.EffectCircuit
namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms isMonomialBounded_rescaledOriginal
end TNLean.PEPS.PairEffect.EffectCircuit
namespace TNLean.PEPS.PairEffect
#print axioms norm_comp_sub_comp_le_one
end TNLean.PEPS.PairEffect
namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms norm_eval_le_one
end TNLean.PEPS.PairEffect.OriginalCircuit
namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms norm_rescaledOriginal_sub_evalWithGateMaps_le
end TNLean.PEPS.PairEffect.EffectCircuit
namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms physicalDensityWithGateMaps
end TNLean.PEPS.PairEffect.EffectCircuit
namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms rectangularTraceNorm_rescaledOriginal_density_sub_le
end TNLean.PEPS.PairEffect.EffectCircuit
namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms rectangularTraceNorm_rescaledOriginal_density_sub_le_budget
end TNLean.PEPS.PairEffect.EffectCircuit
namespace TNLean.PEPS.PairEffect
#print axioms gateApproximation_error_inv_pow_le
end TNLean.PEPS.PairEffect
namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms rectangularTraceNorm_rescaledOriginal_density_sub_le_inv_pow
end TNLean.PEPS.PairEffect.EffectCircuit

run_cmd do
  let environment ← Lean.getEnv
  let names := environment.header.moduleNames.map (fun n ↦ Lean.Json.str n.toString)
  IO.FS.writeFile "../final-verification-20261008/imported-modules.json"
    (Lean.Json.compress (Lean.Json.arr names))
