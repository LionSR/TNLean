import TNLean.PEPS.Approximation.PairSourceCompletion

/-! Empty and singleton party sets require no pair-source slots. -/

noncomputable section

namespace TNLean.PEPS.PairEffect.Regression

private theorem inventory_eq_nil_of_subsingleton {P : Type} [Subsingleton P]
    (S : SourceInventory P) : S = [] := by
  apply List.eq_nil_iff_forall_not_mem.mpr
  intro s _
  exact s.distinct (Subsingleton.elim _ _)

private theorem completion_of_subsingleton {P : Type} [Finite P] [Subsingleton P] :
    ∃ T : SourceInventory P, T = [] ∧ T.IsNormalized ∧
      (T.map PairSource.partyPair).Nodup ∧
      (∀ k, k ∈ T.map PairSource.partyPair ↔ ¬ k.IsDiag) ∧ T.Expands [] := by
  obtain ⟨T, hT, hN, hK, hE⟩ := SourceInventory.exists_complete ([] : SourceInventory P)
    (by intro s hs; cases hs) (by simp)
  exact ⟨T, inventory_eq_nil_of_subsingleton T, hT, hN, hK, hE⟩

/-- Completion over the empty party type introduces no source. -/
theorem empty_completion :
    ∃ T : SourceInventory Empty, T = [] ∧ T.IsNormalized ∧
      (T.map PairSource.partyPair).Nodup ∧
      (∀ k, k ∈ T.map PairSource.partyPair ↔ ¬ k.IsDiag) ∧ T.Expands [] :=
  completion_of_subsingleton

/-- Completion over a single party introduces no source. -/
theorem singleton_completion :
    ∃ T : SourceInventory Unit, T = [] ∧ T.IsNormalized ∧
      (T.map PairSource.partyPair).Nodup ∧
      (∀ k, k ∈ T.map PairSource.partyPair ↔ ¬ k.IsDiag) ∧ T.Expands [] :=
  completion_of_subsingleton

end TNLean.PEPS.PairEffect.Regression
