import UnusedPairCompletionRegression

/-! Imported axiom audit for the empty and singleton regression cases. -/

set_option linter.hashCommand false
#print axioms TNLean.PEPS.PairEffect.Regression.empty_completion
#print axioms TNLean.PEPS.PairEffect.Regression.singleton_completion
