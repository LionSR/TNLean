import TNLean.PEPS.Approximation.WordRestriction
import TNLean.PEPS.Approximation.PartyLocalMaps

noncomputable section
open scoped TensorProduct
open ContinuousLinearMap
namespace TNLean.PEPS.PairEffect.Regression

/-- A scalar local operation still has a named party although both layouts are empty. -/
def scalarWord : Word ([] : Layout Unit) [] :=
  Word.localMap () (ℓ₁ := []) (ℓ₂ := []) (by simp) (by simp)
    ((1 / 2 : ℂ) • ContinuousLinearMap.id ℂ ℂ) []

theorem scalarWord_sources : scalarWord.sources = [] := rfl

theorem scalarWord_isAllowed : scalarWord.IsAllowed := by
  norm_num [scalarWord, Word.IsAllowed, norm_smul]

theorem scalarWord_parties : scalarWord.parties = {()} := by
  simp [scalarWord, Word.parties]

theorem scalarWord_no_empty_cover : ¬ ∀ p ∈ scalarWord.parties, p ∈ ([] : List Unit) := by
  simp [scalarWord, Word.parties]

theorem scalarWord_eval (x : ℂ) : scalarWord.eval x = (1 / 2 : ℂ) * x := by
  simp [scalarWord, Word.eval, appendIso]


theorem group_singleton_empty (x : ℂ) :
    groupByPartyIso [()] ([] : Layout Unit) (by simp) (by simp) x =
      (1 : ℂ) ⊗ₜ[ℂ] x := by
  rfl

def firstReg : Reg (Fin 3) := ⟨0, HSpace.of ℂ⟩
def secondReg : Reg (Fin 3) := ⟨1, HSpace.of ℂ⟩
def reversedLayout : Layout (Fin 3) := [secondReg, firstReg]
def orderedParties : List (Fin 3) := [0, 1, 2]

theorem orderedParties_nodup : orderedParties.Nodup := by decide

theorem reversed_owners : ∀ r ∈ reversedLayout, r.owner ∈ orderedParties := by
  intro r hr
  simp only [reversedLayout, List.mem_cons, List.not_mem_nil, or_false] at hr
  rcases hr with rfl | rfl <;> simp [firstReg, secondReg, orderedParties]

/-- The empty party remains a scalar factor despite the reverse order of the other registers. -/
theorem reversed_layout_with_empty_party : Layout.atParty 0 reversedLayout = [firstReg] ∧
    Layout.atParty 1 reversedLayout = [secondReg] ∧ Layout.atParty 2 reversedLayout = [] := by
  simp [Layout.atParty, Layout.restrict, reversedLayout, firstReg, secondReg]

theorem reversed_register_factorization :
    ∃ B : ∀ p, Mem (Layout.atParty p reversedLayout) →L[ℂ]
        Mem (Layout.atParty p reversedLayout),
      (∀ p, ‖B p‖ ≤ 1) ∧
      isoL (groupByPartyIso orderedParties reversedLayout orderedParties_nodup reversed_owners) ∘L
          (Word.id reversedLayout).eval =
        tensorPartyMaps reversedLayout reversedLayout B orderedParties ∘L
          isoL (groupByPartyIso orderedParties reversedLayout
            orderedParties_nodup reversed_owners) := by
  apply (Word.id reversedLayout).exists_tensorPartyMaps rfl trivial
    orderedParties orderedParties_nodup
  have h : ∀ p : Fin 3, p ∈ orderedParties := by decide
  exact fun p _ ↦ h p

/-- The actual contraction returned by the finite factorization retains the scalar 1/2. -/
theorem scalar_factor_retained : ∃ B : ℂ →L[ℂ] ℂ, ‖B‖ ≤ 1 ∧ B 1 = (1 / 2 : ℂ) := by
  obtain ⟨B, hB, heq⟩ := scalarWord.exists_tensorPartyMaps rfl scalarWord_isAllowed [()]
    (by simp) (by intro p hp; simp)
  let C : ℂ →L[ℂ] ℂ := B ()
  refine ⟨C, hB (), ?_⟩
  have h := DFunLike.congr_fun heq (1 : ℂ)
  change (1 : ℂ) ⊗ₜ[ℂ] scalarWord.eval 1 =
    TensorProduct.mapL (B ()) (ContinuousLinearMap.id ℂ ℂ)
      ((1 : ℂ) ⊗ₜ[ℂ] (1 : ℂ)) at h
  erw [scalarWord_eval, TensorProduct.mapL_tmul] at h
  have hh := congrArg (TensorProduct.lidIsometry ℂ ℂ) h
  erw [TensorProduct.lidIsometry_apply, TensorProduct.lid_tmul,
    TensorProduct.lidIsometry_apply, TensorProduct.lid_tmul] at hh
  change (1 : ℂ) * ((1 / 2 : ℂ) * 1) = C 1 * 1 at hh
  simpa using hh.symm

end TNLean.PEPS.PairEffect.Regression

