import TNLean

/-! Imported axiom check of the new source identities and refactored declarations. -/
set_option linter.hashCommand false

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms gateLocations
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms participants
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect
#print axioms OriginalCircuit
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms IsExpansionBounded
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms card_participants_ne_one
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms eval
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms eval_produce
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms expandedGateCount_produce
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms isAllowed_produce
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms isExpansionBounded_produce_iff
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms nonprivateCount
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms nonprivateLocations
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms participants
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms participants_produce
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms produce
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms produceLocationsEquiv
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.ProductInput
#print axioms mem_owners_wholePartyLayout
end TNLean.PEPS.PairEffect.ProductInput

namespace TNLean.PEPS.PairEffect.ProductInput
#print axioms nodup_owners_wholePartyLayout
end TNLean.PEPS.PairEffect.ProductInput

namespace TNLean.PEPS.PairEffect.ProductInput
#print axioms ofAllParties
end TNLean.PEPS.PairEffect.ProductInput

namespace TNLean.PEPS.PairEffect.ProductInput
#print axioms owners_wholePartyLayout
end TNLean.PEPS.PairEffect.ProductInput

namespace TNLean.PEPS.PairEffect.ProductInput
#print axioms wholePartyLayout
end TNLean.PEPS.PairEffect.ProductInput

namespace TNLean.PEPS.PairEffect
#print axioms card_regionalPhysicalIndex
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms filteredPartyEquiv
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms finrank_physicalLayout
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms finrank_regionalPhysicalSpace
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms finrank_restrict_physicalLayout
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms labelledPhysicalBasis
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms labelledPhysicalReadout
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms length_filter_region
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms norm_regionalPhysicalReadout_le_one
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms physicalLayout
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms physicalLayout_owners
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms physicalListBasis
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms physicalOutputLayout
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms regionalPhysicalIndexEquiv
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms regionalPhysicalReadout
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms regionalPhysicalReadout_apply
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms restrict_physicalLayout
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms restrictedPhysicalBasis
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms exists_replacementLocationsEquiv
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms participants_replacementLocationsEquiv
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms replacementLocationsEquiv
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms participants_replacementLocationsEquiv
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms replacementLocationsEquiv
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms castLocationsEquiv
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms exchangeBlocksLocationsEquivEmpty
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms false_of_gateLocation_ofLocalWord
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms frameListLocationsEquiv
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms ofLocalWordLocationsEquivEmpty
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms participants_castLocationsEquiv
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms participants_frameListLocationsEquiv
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms IsExpansionBounded
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms auxiliary
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms auxiliaryVector
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms expandedGateCount
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms isAllowed_replacement
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms norm_auxiliaryVector
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms replacement
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms eval_frameList
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms isAllowed_exchangeBlocks
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect
#print axioms appendIso_assoc_symm_heq
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms castOutputMap
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms castOutputMap_sub
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms exists_prepared_effectReplacement_native
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms exists_prepared_effectReplacement_uniform
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms gateMemoryMap
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms gateMemoryMap_sub
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms gate_auxiliary_layout
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms norm_castOutputMap
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms norm_gateMemoryMap_le
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms norm_retainMap_le
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms replacementCoefficients
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms retainMap
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms retainMap_sub
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms retainMap_tmul
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms norm_referenceEval_le_one
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms norm_replacement_sub_reference_le
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms referenceEval
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms referenceEval_apply
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms exchangeHead_tmul
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms norm_eval_castLayouts_sub
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect
#print axioms appendIso_singleton_symm_tmul
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms gateMemoryMap_auxiliary_identity
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms gateMemoryMap_auxiliary_tmul
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms gateMemoryMap_tmul
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms preparation_mapOwner_heq
end TNLean.PEPS.PairEffect

namespace Matrix
#print axioms appendAuxiliaryVector
end Matrix

namespace Matrix
#print axioms norm_appendAuxiliaryVector
end Matrix

namespace Matrix
#print axioms partialTraceRight_appendAuxiliaryVector
end Matrix

namespace Matrix
#print axioms rectangularTraceNorm_appendAuxiliaryVector_error_le_two
end Matrix

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms finiteDimensional_auxiliary
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms originalPhysicalDensity
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms rectangularTraceNorm_replacement_density_sub_le
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms replacementPhysicalDensity
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.PartyChain
#print axioms finiteDimensional_sources_prepStack
end TNLean.PEPS.PairEffect.PartyChain

namespace TNLean.PEPS.PairEffect
#print axioms auxiliaryCoordinateIso
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms auxiliaryCoordinateIso_tmul
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms auxiliaryCoordinates
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms extendedPhysicalReadout
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms extendedPhysicalReadout_append_tmul
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms finiteDimensional_mem_append
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms finiteDimensional_sources_comp
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms finiteDimensional_sources_prepGate
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms finiteDimensional_sources_prepWord
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms norm_extendedPhysicalReadout_le_one
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms rectangularTraceNorm_extendedPhysicalReadout_error_le
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms rectangularTraceNorm_sourceOnly_density_sub_le
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms rectangularTraceNorm_sourceOnly_density_sub_le_half
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms rectangularTraceNorm_sourceOnly_density_sub_le_half_of_count_le
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms rectangularTraceNorm_sourceOnly_regional_density_sub_le_half
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms rectangularTraceNorm_sourceOnly_wholeParty_density_sub_le_half
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect
#print axioms sourceGateBudget
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms sourceGateBudget_eq_of_pos
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms sourceGateBudget_pos
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms sourceGateBudget_spec
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms card_replacementLabels_le
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms card_replacementLabels_stackLength_le
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms exists_prepared_effectReplacement_uniform_resources
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms length_wordList_le
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms stackLength_le
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms sum_norm_coeff_wordList
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms sum_norm_replacementCoefficients
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms sum_norm_replacementCoefficients_le
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms IsMonomialBounded
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms isExpansionBounded_replacement
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms IsExpansionBounded
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms isExpansionBounded_castLayouts
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms isExpansionBounded_exchangeBlocks
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms isExpansionBounded_frameList
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms isExpansionBounded_ofLocalWord
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms card_nonprivateLocations
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms natCard_nonprivateLocations
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms nonprivateLocationsFintype
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms participationCount
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms participationCount_replacement
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms participationCount_replacement_le
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms participationLocationsEquiv
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms participationCount
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms card_sourceLocations_replacement_le
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.PreparedSourceGate
#print axioms length_slots
end TNLean.PEPS.PairEffect.PreparedSourceGate

namespace TNLean.PEPS.PairEffect.PreparedSourceGate
#print axioms length_sources_branchWord
end TNLean.PEPS.PairEffect.PreparedSourceGate

namespace TNLean.PEPS.PairEffect.PreparedSourceGate
#print axioms length_sources_branchWord_eq_choose
end TNLean.PEPS.PairEffect.PreparedSourceGate

namespace TNLean.PEPS.PairEffect.PreparedSourceGate
#print axioms length_sources_branchWord_le_choose
end TNLean.PEPS.PairEffect.PreparedSourceGate

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms card_sourceLocations_eq_sum_choose
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms card_sourceLocations_le
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms slotCount_eq_choose
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect
#print axioms card_familyRegionalPhysicalIndex
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms familyLabelledPhysicalBasis
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms familyLabelledPhysicalReadout
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms familyPhysicalLayout
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms familyPhysicalLayout_const
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms familyPhysicalLayout_owners
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms familyPhysicalListBasis
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms familyPhysicalOutputLayout
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms familyRegionalPhysicalIndexEquiv
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms familyRegionalPhysicalReadout
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms familyRegionalPhysicalReadout_apply
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms familyRestrictedPhysicalBasis
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms finrank_restrict_familyPhysicalLayout
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms finrank_restrict_familyPhysicalLayout_le
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms norm_familyRegionalPhysicalReadout_le_one
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms restrict_familyPhysicalLayout
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect.OriginalCircuit
#print axioms rectangularTraceNorm_sourceOnly_family_regional_density_sub_le_half
end TNLean.PEPS.PairEffect.OriginalCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit.IsExpansionBounded
#print axioms at_gate
end TNLean.PEPS.PairEffect.SourceCircuit.IsExpansionBounded

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms participationCount_eq_card_incidentGates
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect
#print axioms EffectCircuit
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms IsAllowed
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms eval
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.EffectCircuit
#print axioms norm_eval_le_one
end TNLean.PEPS.PairEffect.EffectCircuit

namespace TNLean.PEPS.PairEffect.PartyChain
#print axioms isPreparation_prepStack
end TNLean.PEPS.PairEffect.PartyChain

namespace TNLean.PEPS.PairEffect
#print axioms ProductInput
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect.ProductInput
#print axioms eval_prepare
end TNLean.PEPS.PairEffect.ProductInput

namespace TNLean.PEPS.PairEffect.ProductInput
#print axioms eval_prepare_smul
end TNLean.PEPS.PairEffect.ProductInput

namespace TNLean.PEPS.PairEffect.ProductInput
#print axioms isAllowed_prepare
end TNLean.PEPS.PairEffect.ProductInput

namespace TNLean.PEPS.PairEffect.ProductInput
#print axioms mapOwner
end TNLean.PEPS.PairEffect.ProductInput

namespace TNLean.PEPS.PairEffect.ProductInput
#print axioms mapOwnerIso_vector
end TNLean.PEPS.PairEffect.ProductInput

namespace TNLean.PEPS.PairEffect.ProductInput
#print axioms norm_vector
end TNLean.PEPS.PairEffect.ProductInput

namespace TNLean.PEPS.PairEffect.ProductInput
#print axioms ofParties
end TNLean.PEPS.PairEffect.ProductInput

namespace TNLean.PEPS.PairEffect.ProductInput
#print axioms partitionIso_symm_mapOwner_vector
end TNLean.PEPS.PairEffect.ProductInput

namespace TNLean.PEPS.PairEffect.ProductInput
#print axioms partitionIso_symm_vector
end TNLean.PEPS.PairEffect.ProductInput

namespace TNLean.PEPS.PairEffect.ProductInput
#print axioms partitionIso_vector
end TNLean.PEPS.PairEffect.ProductInput

namespace TNLean.PEPS.PairEffect.ProductInput
#print axioms prepare
end TNLean.PEPS.PairEffect.ProductInput

namespace TNLean.PEPS.PairEffect.ProductInput
#print axioms prepareIsometry
end TNLean.PEPS.PairEffect.ProductInput

namespace TNLean.PEPS.PairEffect.ProductInput
#print axioms restrict
end TNLean.PEPS.PairEffect.ProductInput

namespace TNLean.PEPS.PairEffect.ProductInput
#print axioms sources_prepare
end TNLean.PEPS.PairEffect.ProductInput

namespace TNLean.PEPS.PairEffect.ProductInput
#print axioms vector
end TNLean.PEPS.PairEffect.ProductInput

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms castLayouts
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms eval_castLayouts
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms eval_exchangeBlocks
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms eval_frameList_tmul
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms eval_ofLocalWord
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms exchangeBlocks
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms frameList
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms isAllowed_castLayouts
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms isAllowed_frameList
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms isAllowed_ofLocalWord
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms ofLocalWord
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms norm_vector
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.Word
#print axioms IsPreparation
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Word
#print axioms eval_isPreparation_cast
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Word
#print axioms eval_isPreparation_heq
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Word
#print axioms eval_localPrepare
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Word
#print axioms isAllowed_localPrepare
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Word
#print axioms localPrepare
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Word
#print axioms output_of_isPreparation
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect
#print axioms exists_prepared_effectReplacement
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms isPreparation_prepGate
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms isPreparation_prepWord
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms eval_prepareSourcePositions_append
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms eval_prepareSourcePositions_filter
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms eval_prepareSourcePositions_heq
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms exists_reorderFreeSlots
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms exists_reorderSourcePositions
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms prepareSourcePositions
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms selectedSources_eq_map
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms slotReference
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms sourcePositionsLayout
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms sourcePositionsLayout_append
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms sourcePositionsLayout_eq_layout
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms sourcePositionsLayout_filter
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.Word
#print axioms eval_castLayouts_apply_heq
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Layout
#print axioms memCongr_append_tmul
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.Layout
#print axioms memCongr_apply_heq
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms correctedFreeSlots_eq_or
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms correctedFreeSlots_masks
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms correctedSlotMask
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms correctedSlotMask_endpoints
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms correctedSourceLayout
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms correctedSourceLayout_owners
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms crossingSlotMask
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms crossingSlotMask_eq_false_of_corrected
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms crossingSourceLayout
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms exists_sourceCrossing_schmidt
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms norm_sourceCrossingVector
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms restrict_correctedSourceLayout_append
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms sourceCrossingVector
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms crossingSourceVector
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms eval_prepareFreeSlots_eq_appendIso_symm
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms freeSourceVector
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms mem_freeSlotLayout
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms norm_crossingSourceVector
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms norm_freeSourceVector
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms exists_correctedInputReordering
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms hasTensorPartition_prepared_reordered_partial
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms hasTensorPartition_reordered_partial
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms eval_framed_freeSourceVectors
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms eval_framed_sourceVector
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms eval_prepareFreeSlots_nil_heq
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms eval_prepare_nil_heq
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms eval_reordered_prepared_vector
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms preparedReorderedWord
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms sourceVectorPair
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms vector_append_eq
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms vector_append_heq
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.Word
#print axioms eval_source_apply_heq
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms correctedInputPreparation
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms correctedInputVector
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms correctedInputVector_identity_of_reordering
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms correctedPreparedWord
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms HasCorrectedInputVectors
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms exists_correctedInputVector_identity
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms matrixFrame
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms matrixFrame_basis
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms selectedSourceFrame
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms selectedSourceFrame_basis
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms selectedSourceFrame_basis_prepare
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms sourcePositionsFrame
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms sourcePositionsFrame_basis_prepare
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms correctedSourceFrame
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms correctedSourceFrame_basis
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceInventory
#print axioms freeSourceVector_congr
end TNLean.PEPS.PairEffect.SourceInventory

namespace TNLean.PEPS.PairEffect
#print axioms HasSchmidtInputFrames
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms exists_correctedInputFrames
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.Word
#print axioms HasSchmidtOutput
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Word
#print axioms hasSchmidtOutput_of_hasTensorPartition
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms HasCorrectedSchmidtInputs
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms correctedMask_meets
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms exists_correctedSchmidtInput_identity
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.SourceCircuit
#print axioms exists_correctedSchmidtOutput
end TNLean.PEPS.PairEffect.SourceCircuit

namespace TNLean.PEPS.PairEffect.Layout
#print axioms mapOwner_tensorBasis_coordinates
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.Layout
#print axioms memCongr_tmul_heq
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.Layout
#print axioms partitionAppendBasis
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.Layout
#print axioms partitionBasis
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.Layout
#print axioms partitionBasis_coordinates
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.Layout
#print axioms partitionBasis_coordinates_of_eq
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.Layout
#print axioms partitionIso_partitionBasis_tmul
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.Layout
#print axioms partitionOutputIso
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.Layout
#print axioms partitionOutputIso_basis
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.Layout
#print axioms partitionOutputIso_coordinates
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.Layout
#print axioms mapOwner_mapOwner_partitionBasis_coordinates
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.Layout
#print axioms mapOwner_mapOwner_tensorBasis_coordinates
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.Layout
#print axioms mapOwner_mapOwner_coordinates_eq_separated
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.Layout
#print axioms partition_coordinates_eq_separated
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.Layout
#print axioms regionalOutputIso
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.Word
#print axioms repr_effectMap
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Layout
#print axioms affectedOutputIso
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.Layout
#print axioms restrictMapOwnerIso
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.Layout
#print axioms restrict_mapOwner
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect
#print axioms affectedFamilyPhysicalBasis
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect
#print axioms finrank_affectedFamilyPhysicalLayout
end TNLean.PEPS.PairEffect

namespace TNLean.PEPS.PairEffect.Layout
#print axioms physicalDiscardIso
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.Layout
#print axioms physicalDiscardIso_tmul
end TNLean.PEPS.PairEffect.Layout

namespace TNLean.PEPS.PairEffect.Word
#print axioms norm_physicalComponentCoordinates_le_one
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Word
#print axioms norm_physicalComponent_le_one
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Word
#print axioms norm_physicalGramMap_le_one
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Word
#print axioms norm_physicalGramMatrix_le_one
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Word
#print axioms partialTrace_physicalOutputMatrix_mul_conjTranspose
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Word
#print axioms physicalComponent
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Word
#print axioms physicalComponentCoordinates
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Word
#print axioms physicalGramMap
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Word
#print axioms physicalGramMap_inner
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Word
#print axioms physicalGramMatrix
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Word
#print axioms physicalGramMatrix_apply
end TNLean.PEPS.PairEffect.Word

namespace TNLean.PEPS.PairEffect.Word
#print axioms physicalOutputMatrix
end TNLean.PEPS.PairEffect.Word

run_cmd do
  let e ← Lean.getEnv
  let ns := e.header.moduleNames.map (fun n ↦ Lean.Json.str n.toString)
  IO.FS.writeFile "imported-modules.json" (Lean.Json.compress (Lean.Json.arr ns))
